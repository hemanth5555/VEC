#!/bin/bash

# This is a simple Bash script to execute a Python file

# Execute the Python script in the current directory
python3 staging/unzipped/zipcon/HealthInformatics.py
